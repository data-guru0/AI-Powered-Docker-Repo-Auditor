import boto3, os
dynamodb = boto3.resource("dynamodb")
attr = boto3.dynamodb.conditions.Attr

def handler(event, context):
    connection_id = event["requestContext"]["connectionId"]
    table = dynamodb.Table(os.environ["WS_CONNECTIONS_TABLE"])
    resp = table.scan(FilterExpression=attr("connection_id").eq(connection_id))
    for item in resp.get("Items", []):
        table.delete_item(Key={"job_id": item["job_id"], "connection_id": connection_id})
    return {"statusCode": 200, "body": "Disconnected"}
