import os, json, urllib.request
from jose import jwt, jwk

REGION = os.environ["AWS_ACCOUNT_REGION"]
USER_POOL_ID = os.environ["COGNITO_USER_POOL_ID"]
CLIENT_ID = os.environ["COGNITO_CLIENT_ID"]
JWKS_URL = f"https://cognito-idp.{REGION}.amazonaws.com/{USER_POOL_ID}/.well-known/jwks.json"
_jwks = None

def get_jwks():
    global _jwks
    if not _jwks:
        with urllib.request.urlopen(JWKS_URL) as r:
            _jwks = json.loads(r.read())
    return _jwks

def handler(event, context):
    token = (event.get("queryStringParameters") or {}).get("token", "")
    try:
        kid = jwt.get_unverified_headers(token)["kid"]
        key = next(k for k in get_jwks()["keys"] if k["kid"] == kid)
        claims = jwt.decode(token, jwk.construct(key), algorithms=["RS256"], audience=CLIENT_ID)
        return {
            "principalId": claims["sub"],
            "policyDocument": {"Version": "2012-10-17", "Statement": [{"Action": "execute-api:Invoke", "Effect": "Allow", "Resource": event["methodArn"]}]},
            "context": {"userId": claims["sub"]}
        }
    except Exception:
        raise Exception("Unauthorized")
