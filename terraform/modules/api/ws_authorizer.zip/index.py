import base64, json

def handler(event, context):
    token = (event.get("queryStringParameters") or {}).get("token", "")
    try:
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError("Invalid token")
        padding = 4 - len(parts[1]) % 4
        payload = json.loads(base64.urlsafe_b64decode(parts[1] + "=" * padding))
        user_id = payload.get("sub", "")
        if not user_id:
            raise ValueError("No sub claim")
        return {
            "principalId": user_id,
            "policyDocument": {"Version": "2012-10-17", "Statement": [{"Action": "execute-api:Invoke", "Effect": "Allow", "Resource": event["methodArn"]}]},
            "context": {"userId": user_id}
        }
    except Exception:
        raise Exception("Unauthorized")
