import boto3, os
dynamodb = boto3.resource("dynamodb")

def handler(event, context):
    connection_id = event["requestContext"]["connectionId"]
    job_id = (event.get("queryStringParameters") or {}).get("jobId", "")
    if job_id:
        table = dynamodb.Table(os.environ["WS_CONNECTIONS_TABLE"])
        table.put_item(Item={"job_id": job_id, "connection_id": connection_id})
    return {"statusCode": 200, "body": "Connected"}
